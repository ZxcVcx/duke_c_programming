#include <stdio.h>
#include <stdlib.h>

#include "cards.h"
#include "deck.h"
#include "eval.h"

int main(void) {
  deck_t * deck = malloc(sizeof(*deck));
  deck->cards = NULL;
  deck->n_cards = 0;
  add_card_to(deck, card_from_letters('K', 's'));
  add_card_to(deck, card_from_letters('K', 'c'));
  add_card_to(deck, card_from_letters('Q', 's'));
  add_card_to(deck, card_from_letters('Q', 'c'));
  add_card_to(deck, card_from_letters('0', 's'));
  add_card_to(deck, card_from_letters('9', 'c'));
  add_card_to(deck, card_from_letters('9', 'h'));
  add_card_to(deck, card_from_letters('9', 's'));
  sort_hand(deck);

  unsigned * match_counts = get_match_counts(deck);
  for (int i = 0; i < deck->n_cards; i++) {
    printf("%u ", match_counts[i]);
  }
  printf("\n");

  print_card(*add_empty_card(deck));
  free(match_counts);
  
  free_deck(deck);
  return EXIT_SUCCESS;
}
