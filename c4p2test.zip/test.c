#include <stdio.h>
#include <stdlib.h>

#include "cards.h"
#include "deck.h"
#include "eval.h"
#include "future.h"
#include "input.h"

void test_future() {
  deck_t * deck = malloc(sizeof(*deck));
  deck->cards = NULL;
  deck->n_cards = 0;
  add_card_to(deck, card_from_letters('K', 's'));
  add_card_to(deck, card_from_letters('K', 'c'));
  add_card_to(deck, card_from_letters('Q', 's'));
  add_card_to(deck, card_from_letters('9', 'h'));
  
  future_cards_t * fc = malloc(sizeof(*fc));
  fc->decks = NULL;
  fc->n_decks = 0;

  card_t * test_card = malloc(sizeof(*test_card));
  *test_card = card_from_letters('3', 'd');
  
  add_future_card(fc, 3, test_card);
  
  printf("%ld\n", fc->n_decks);
  print_card(*fc->decks[3].cards[0]);
  printf("\n");

  // free(test_card);

  future_cards_from_deck(deck, fc);

  print_card(*fc->decks[3].cards[0]);
  printf("\n");

  
  for (int i = 0; i < fc->n_decks; i++) {
    for (int j = 0; j < fc->decks[i].n_cards; j++) {
      if (fc->decks[i].cards != NULL) {
	free(fc->decks[i].cards[j]);
      }
    }
    free(fc->decks[i].cards);
  }
  free(fc->decks);
  free(fc);

  free_deck(deck);
  

}

void print_future(future_cards_t * fc) {
  for (size_t i = 0; i < fc->n_decks; i++) {
    printf("deck %ld: ", i);
    for (size_t j = 0; j < fc->decks[i].n_cards; j++) {
      print_card(*fc->decks[i].cards[j]);
      printf(" ");
    }
    printf("\n");
  }
}

void print_hands(deck_t ** decks, size_t * n_hands) {
  for (int i = 0; i < *n_hands; i++) {
    for (int j = 0; j < decks[i]->n_cards; j++) {
      print_card(*decks[i]->cards[j]);
      printf(" ");
    }
    printf("\n");
  }
}

deck_t * make_a_deck(size_t n_cards) {
  deck_t * deck = malloc(sizeof(*deck));
  deck->n_cards = 0;
  deck->cards = NULL;
  for (int i = 20; i < 20 + n_cards; i++) {
    add_card_to(deck, card_from_num(i));
  }
  return deck;
}
void test_input() {
  FILE * f = fopen("input5.txt", "r");
  if (f == NULL) {
    fprintf(stderr, "Failed to read the test file.\n");
    return;
  }

  future_cards_t * fc = malloc(sizeof(*fc));
  fc->decks = NULL;
  fc->n_decks = 0;

  size_t n_hands = 0;
  deck_t ** decks = read_input(f, &n_hands, fc);

  printf("Hands:\n");
  print_hands(decks, &n_hands);
  
  printf("Futures:\n");
  print_future(fc);

  deck_t * future = make_a_deck(20);
  future_cards_from_deck(future, fc);

  printf("Hands:\n");
  print_hands(decks, &n_hands);
  
  printf("Futures:\n");
  print_future(fc);

  free_deck(future);
  
  
  for (int i = 0; i < fc->n_decks; i++) {
    /* for (int j = 0; j < fc->decks[i].n_cards; j++) { */
    /*   if (fc->decks[i].cards != NULL) { */
    /* 	free(fc->decks[i].cards[j]); */
    /*   } */
    /* } */
    free(fc->decks[i].cards);
  }
  free(fc->decks);
  free(fc);

  for (int i = 0; i < n_hands; i++) {
    free_deck(decks[i]);
  }
  free(decks);

  if (fclose(f) == EOF) {
    fprintf(stderr, "Failed to close the test file.\n");
    return;
  }
  
}

int main(void) {
  // test_future();
  test_input();
  
  return EXIT_SUCCESS;
}
